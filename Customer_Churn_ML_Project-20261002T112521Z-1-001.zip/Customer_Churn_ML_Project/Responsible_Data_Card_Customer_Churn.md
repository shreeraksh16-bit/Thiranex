# Responsible Data Card

## Dataset purpose
The dataset is used to develop and evaluate a machine learning model for predicting customer churn. The purpose is to understand customer behavior and identify customers who may be at risk of leaving a service.
The dataset is intended for machine learning experimentation, baseline modelling, and responsible evaluation of customer-churn prediction.

## Provenance and permission
The dataset was provided as part of the Customer Churn ML task.
The exact original data-collection source, collection process, and licensing or permission details are not provided in the supplied dataset. These details should be verified with the dataset provider before using the data outside the intended task.

## Population and representation
The dataset contains 12 customer records.
The represented population consists of customers included in the supplied Customer Churn training data. Because the dataset contains only 12 records, it may not adequately represent the broader customer population.
The small sample size may limit the generalizability of the model's results.

## Features and target
Features
The original dataset contains:
1.Customer ID
2.Tenure Months
3.Support Tickets
4.Monthly Spend in INR
5.Last Login Days
6.Plan Type
7.Churned

For model training, Customer ID is excluded because it is an identifier rather than a meaningful predictive feature.
The modelling features are:
Tenure Months
Support Tickets
Monthly Spend in INR
Last Login Days
Plan Type
Target
The target variable is Churned.
0 — Not Churned
1 — Churned

## Quality checks
-The following quality checks were performed:
-Dataset contains 12 records and 7 columns.
-Missing-value check was performed and no missing values were found.
-Duplicate rows were checked.
-Duplicate Customer IDs were checked.
-The target-class distribution was examined.
-Data types of the features were inspected.
-Customer ID was excluded from model training.
-The categorical feature, Plan Type, was encoded before modelling.

## Risks and safeguards
Risks
-Potential risks include:
-Very small dataset size may result in unreliable model performance.
-Class imbalance may affect prediction quality.
-Incorrect predictions may result in customers being incorrectly identified as churn risks.
-Customer identifiers or unnecessary personal information could create privacy concerns.
-The dataset may not represent the full customer population.
-The model may become less reliable if customer behavior changes over time.

Safeguards
-The following safeguards are recommended:
-Do not use Customer ID as a predictive feature.
-Use the model as a decision-support tool rather than an automatic decision-maker.
-Review model predictions before taking action.
-Monitor performance on new data.
-Evaluate performance across relevant customer groups when appropriate data is available.
-Avoid using unnecessary personal information.
-Do not use predictions as the sole basis for denying services or penalizing customers.

## Intended evaluation
The baseline model is evaluated using:
-Accuracy
-Precision
-Recall
-F1-score
-Confusion Matrix
Recall is an important metric for churn prediction because it measures how many customers who actually churned were correctly identified by the model.
Because the dataset contains only 12 records, the evaluation results should be treated as an exploratory baseline and not as evidence that the model is ready for real-world deployment.
